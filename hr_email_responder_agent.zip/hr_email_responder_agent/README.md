# AI-Email-Response-Agent-Using-LangChain
The project aims to streamline and automate HR email handling by leveraging AI-powered classification, response generation, and state flow management. It focuses on key HR functional areas such as recruitment, employee relations, compensation, training, performance management, compliance, engagement, HR analytics, and exit management.
